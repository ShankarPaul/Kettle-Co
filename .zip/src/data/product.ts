/**
 * Mock product data for the Aurora Pour-Over Kettle product page.
 * This data structure is designed to be reusable across product pages
 * and easily replaceable with an API response in future phases.
 */

export interface ProductVariant {
  name: string;
  color: string;
  price: number;
  inStock: boolean;
}

export interface ProductSpec {
  label: string;
  value: string;
}

export interface ProductImage {
  id: string;
  src: string;
  alt: string;
}

export interface Product {
  id: string;
  name: string;
  basePrice: number;
  rating: number;
  reviews: number;
  description: string;
  images: ProductImage[];
  variants: ProductVariant[];
  specs: ProductSpec[];
}

/**
 * Generate a placeholder image URL using a solid color with text overlay.
 * In production, these would be real product photography URLs.
 */

export const product: Product = {
  id: "aurora-pour-over-kettle",
  name: "Aurora Pour-Over Kettle",
  basePrice: 95,
  rating: 4.8,
  reviews: 247,
  description:
    "Hand-crafted ceramic kettle with precision pour spout. 1.2L capacity. Perfect for pour-over coffee.",

  images: [
    {
      id: "main",
      src: "/images/kettle-main.png",
      alt: "Aurora Pour-Over Kettle in Cream color - main product image",
    },
    {
      id: "thumb-1",
      src: "/images/kettle-side.png",
      alt: "Aurora Kettle in Cream color - thumbnail 1",
    },
    {
      id: "thumb-2",
      src: "/images/kettle-top.png",
      alt: "Aurora Kettle in Cream color - thumbnail 2",
    },
    {
      id: "thumb-3",
      src: "/images/kettle-detail.png",
      alt: "Aurora Kettle in Cream color - thumbnail 3",
    },
  ],

  variants: [
    { name: "Cream", color: "#F5F5F5", price: 95, inStock: true },
    { name: "Charcoal", color: "#2D3436", price: 98, inStock: true },
    { name: "Sage Green", color: "#6B9B7F", price: 98, inStock: false },
    { name: "Terracotta", color: "#CC6B4A", price: 98, inStock: true },
  ],

  specs: [
    { label: "Capacity", value: "1.2L" },
    { label: "Material", value: "Ceramic with steel handle" },
    { label: "Height", value: "18cm" },
    { label: "Weight", value: "650g" },
    { label: "Heat resistant", value: "Up to 220°C" },
    { label: "Dishwasher safe", value: "Yes" },
    { label: "Warranty", value: "2 years" },
  ],
};
