/**
 * Product image gallery component.
 * Features a large main image with swappable thumbnails below.
 * Responsive: 3 thumbnails on desktop, 2 per row on mobile.
 */

import type { ProductImage } from "../data/product";

interface GalleryProps {
  images: ProductImage[];
  selectedImageIndex: number;
  onSelectImage: (index: number) => void;
  isLoading?: boolean;
}

export default function Gallery({
  images,
  selectedImageIndex,
  onSelectImage,
  isLoading = false,
}: GalleryProps) {
  if (isLoading) {
    return (
      <div className="flex flex-col gap-[var(--sp-md)]">
        {/* Main image skeleton */}
        <div className="skeleton w-full aspect-square max-h-[400px]" />
        {/* Thumbnail skeletons */}
        <div className="flex gap-[var(--sp-sm)]">
          {[0, 1, 2].map((i) => (
            <div key={i} className="skeleton w-20 h-20 shrink-0" />
          ))}
        </div>
      </div>
    );
  }

  const mainImage = images[selectedImageIndex];

  return (
    <div className="flex flex-col gap-[var(--sp-md)]">
      {/* Main product image */}
      <div className="relative w-full aspect-square max-h-[500px] bg-white rounded-[var(--radius-card)]
        overflow-hidden shadow-sm border border-gray-100">
        <img
          src={mainImage.src}
          alt={mainImage.alt}
          className="w-full h-full object-cover transition-all duration-300 ease-in-out"
          loading="eager"
        />
      </div>

      {/* Thumbnail strip */}
      <div
        className="grid gap-[var(--sp-sm)]
          grid-cols-2 sm:grid-cols-3"
        role="listbox"
        aria-label="Product image thumbnails"
      >
        {images.slice(1).map((image, index) => {
          const thumbIndex = index + 1;
          const isSelected = selectedImageIndex === thumbIndex;
          return (
            <button
              key={image.id}
              role="option"
              aria-selected={isSelected}
              aria-label={image.alt}
              onClick={() => onSelectImage(thumbIndex)}
              className={`relative aspect-square rounded-[var(--radius-button)] overflow-hidden
                border-2 transition-all duration-300 cursor-pointer bg-white
                hover:shadow-md hover:scale-[1.02]
                ${isSelected
                  ? "border-accent shadow-md ring-1 ring-accent/30"
                  : "border-gray-200 hover:border-gray-300"
                }`}
            >
              <img
                src={image.src}
                alt={image.alt}
                className="w-full h-full object-cover"
                loading="lazy"
              />
            </button>
          );
        })}
      </div>
    </div>
  );
}
