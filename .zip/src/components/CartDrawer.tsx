import { useEffect, useRef, useCallback } from "react";
import { product } from "../data/product";

export interface CartItem {
  variantIndex: number;
  quantity: number;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (variantIndex: number, quantity: number) => void;
  onRemoveItem: (variantIndex: number) => void;
  onCheckout: () => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
}: CartDrawerProps) {
  const drawerRef = useRef<HTMLDivElement>(null);

  // Close drawer on ESC key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  // Prevent background scrolling when cart is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  // Focus trap on open
  useEffect(() => {
    if (isOpen && drawerRef.current) {
      // Focus the close button or first interactive element
      const interactive = drawerRef.current.querySelector("button");
      if (interactive) {
        interactive.focus();
      }
    }
  }, [isOpen]);

  const subtotal = cartItems.reduce((acc, item) => {
    const variant = product.variants[item.variantIndex];
    return acc + variant.price * item.quantity;
  }, 0);

  const handleCheckoutClick = useCallback(() => {
    onClose();
    onCheckout();
  }, [onClose, onCheckout]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden" role="dialog" aria-modal="true" aria-label="Shopping Cart">
      {/* Semi-transparent Backdrop overlay */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-300 animate-fade-in"
        onClick={onClose}
      />

      {/* Sliding Drawer Container */}
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div
          ref={drawerRef}
          className="w-screen max-w-md bg-white shadow-2xl flex flex-col transform transition-transform duration-300 ease-in-out border-l border-gray-100 animate-slide-in-right"
        >
          {/* Header */}
          <div className="px-6 py-5 border-b border-gray-100 flex items-center justify-between">
            <h2 className="text-lg font-bold text-primary flex items-center gap-2">
              <svg className="w-5 h-5 text-accent" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
              Your Shopping Cart ({cartItems.reduce((acc, item) => acc + item.quantity, 0)})
            </h2>
            <button
              onClick={onClose}
              className="p-2 -mr-2 text-secondary hover:text-primary rounded-full hover:bg-gray-100 transition-colors focus-visible:outline-accent cursor-pointer"
              aria-label="Close cart drawer"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* Cart Contents */}
          <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-6">
            {cartItems.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center py-12">
                <div className="w-20 h-20 rounded-full bg-neutral-bg flex items-center justify-center mb-4 text-gray-400">
                  <svg className="w-10 h-10" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.12-1.243l1.264-12A1.125 1.125 0 015.513 7.5h12.974c.576 0 1.059.435 1.119 1.007zM8.625 10.5a.375.375 0 11-.75 0 .375.375 0 01.75 0zm7.5 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
                  </svg>
                </div>
                <h3 className="text-base font-bold text-primary mb-1">Your cart is empty</h3>
                <p className="text-sm text-secondary max-w-[240px] mb-6">
                  Add items to your cart to see them here. Let's find some products!
                </p>
                <button
                  onClick={onClose}
                  className="px-5 py-2.5 bg-primary text-white text-sm font-semibold rounded-[var(--radius-button)] hover:bg-neutral-text transition-colors cursor-pointer focus-visible:outline-accent"
                >
                  Start Shopping
                </button>
              </div>
            ) : (
              cartItems.map((item) => {
                const variant = product.variants[item.variantIndex];
                return (
                  <div key={item.variantIndex} className="flex gap-4 pb-6 border-b border-gray-100 last:border-b-0 last:pb-0">
                    {/* Variant Color Preview Swatch as Thumbnail */}
                    <div
                      className="w-16 h-16 rounded-[var(--radius-card)] bg-neutral-bg flex items-center justify-center border border-gray-200/50 shadow-inner relative overflow-hidden"
                      aria-hidden="true"
                    >
                      {/* Sub-variant small color circle */}
                      <span
                        className="w-8 h-8 rounded-full border border-gray-300 shadow-sm"
                        style={{ backgroundColor: variant.color }}
                      />
                    </div>

                    {/* Variant Details */}
                    <div className="flex-1 flex flex-col justify-between">
                      <div className="flex justify-between items-start gap-2">
                        <div>
                          <h3 className="text-sm font-bold text-primary leading-tight">{product.name}</h3>
                          <p className="text-xs text-secondary mt-0.5">Color: {variant.name}</p>
                        </div>
                        <p className="text-sm font-bold text-primary">£{variant.price.toFixed(2)}</p>
                      </div>

                      {/* Controls Row */}
                      <div className="flex justify-between items-center mt-3">
                        {/* Compact Quantity Selector */}
                        <div className="flex items-center border border-gray-200 rounded-[var(--radius-button)] bg-gray-50/50 p-0.5">
                          <button
                            type="button"
                            disabled={item.quantity <= 1}
                            onClick={() => onUpdateQuantity(item.variantIndex, item.quantity - 1)}
                            className="w-7 h-7 flex items-center justify-center text-secondary hover:text-primary disabled:opacity-30 disabled:cursor-not-allowed hover:bg-white rounded-[6px] transition-colors focus-visible:outline-accent"
                            aria-label="Decrease quantity"
                          >
                            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M20 12H4" />
                            </svg>
                          </button>
                          <span className="w-8 text-center text-xs font-bold text-primary" aria-label={`Quantity: ${item.quantity}`}>
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            disabled={item.quantity >= 10}
                            onClick={() => onUpdateQuantity(item.variantIndex, item.quantity + 1)}
                            className="w-7 h-7 flex items-center justify-center text-secondary hover:text-primary disabled:opacity-30 disabled:cursor-not-allowed hover:bg-white rounded-[6px] transition-colors focus-visible:outline-accent"
                            aria-label="Increase quantity"
                          >
                            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 4v16m8-8H4" />
                            </svg>
                          </button>
                        </div>

                        {/* Remove Button */}
                        <button
                          type="button"
                          onClick={() => onRemoveItem(item.variantIndex)}
                          className="text-xs font-medium text-red-500 hover:text-red-700 transition-colors p-1.5 flex items-center gap-1 hover:bg-red-50 rounded-[var(--radius-button)] cursor-pointer focus-visible:outline-red-500"
                          aria-label={`Remove ${variant.name} variant from cart`}
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                          Remove
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer (Pricing Summary & Call-To-Action) */}
          {cartItems.length > 0 && (
            <div className="px-6 py-6 border-t border-gray-100 bg-gray-50/50">
              <div className="flex justify-between items-center mb-4">
                <span className="text-sm text-secondary font-medium">Subtotal</span>
                <span className="text-lg font-extrabold text-primary">£{subtotal.toFixed(2)}</span>
              </div>
              <p className="text-xs text-secondary mb-6 leading-normal">
                Shipping and taxes calculated at checkout. Free shipping over £150.
              </p>
              <button
                type="button"
                onClick={handleCheckoutClick}
                className="w-full py-4 bg-accent text-white font-bold rounded-[var(--radius-button)] shadow-md shadow-accent/25 hover:bg-[#e85555] hover:shadow-lg transition-all active:scale-[0.99] cursor-pointer text-center block focus-visible:outline-accent"
              >
                Proceed to Checkout
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
