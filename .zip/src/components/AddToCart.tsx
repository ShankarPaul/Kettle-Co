/**
 * Add to Cart button component.
 * Shows "Add to Cart" when in stock, "Out of Stock" when not.
 * Triggers a success toast notification on click.
 */

interface AddToCartProps {
  /** Whether the selected variant is in stock */
  inStock: boolean;
  /** Callback when the button is clicked */
  onAddToCart: () => void;
  isLoading?: boolean;
}

export default function AddToCart({
  inStock,
  onAddToCart,
  isLoading = false,
}: AddToCartProps) {
  if (isLoading) {
    return <div className="skeleton h-14 w-full sm:w-auto sm:min-w-[200px] rounded-[var(--radius-button)]" />;
  }

  return (
    <button
      type="button"
      disabled={!inStock}
      onClick={onAddToCart}
      aria-label={inStock ? "Add to Cart" : "Out of Stock"}
      className={`w-full sm:w-auto px-6 py-4 rounded-[var(--radius-button)]
        text-base font-bold tracking-wide
        transition-all duration-300 ease-in-out
        min-h-[44px] cursor-pointer
        ${inStock
          ? `bg-accent text-white shadow-lg shadow-accent/25
             hover:bg-[#e85555] hover:shadow-xl hover:shadow-accent/30
             hover:scale-[1.02] active:scale-[0.98]
             active:shadow-md`
          : `bg-gray-300 text-gray-500 cursor-not-allowed
             shadow-none`
        }`}
    >
      {inStock ? "Add to Cart" : "Out of Stock"}
    </button>
  );
}
