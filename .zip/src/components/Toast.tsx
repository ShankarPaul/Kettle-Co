/**
 * Toast notification component.
 * Slides in from the right with auto-hide after a configurable duration.
 * Supports success, warning, and error states.
 */

import { useEffect, useState } from "react";

interface ToastProps {
  message: string;
  /** Duration in ms before auto-hiding */
  duration?: number;
  /** Called when toast finishes hiding */
  onClose: () => void;
  type?: "success" | "warning" | "error";
}

export default function Toast({
  message,
  duration = 3000,
  onClose,
  type = "success",
}: ToastProps) {
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    // Start exit animation before the toast is removed
    const exitTimer = setTimeout(() => {
      setIsExiting(true);
    }, duration - 300);

    // Remove toast after full duration
    const removeTimer = setTimeout(() => {
      onClose();
    }, duration);

    return () => {
      clearTimeout(exitTimer);
      clearTimeout(removeTimer);
    };
  }, [duration, onClose]);

  // Determine background color based on toast type
  const bgColorClass =
    type === "success"
      ? "bg-success"
      : type === "warning"
        ? "bg-warning"
        : "bg-accent";

  return (
    <div
      role="alert"
      aria-live="polite"
      className={`fixed top-6 right-6 z-50 max-w-sm ${isExiting ? "toast-exit" : "toast-enter"}`}
    >
      <div
        className={`${bgColorClass} text-white px-6 py-4 rounded-[var(--radius-card)] shadow-xl
          flex items-center gap-3 text-sm font-medium leading-snug`}
      >
        <span className="text-lg shrink-0">✓</span>
        <span>{message}</span>
      </div>
    </div>
  );
}
