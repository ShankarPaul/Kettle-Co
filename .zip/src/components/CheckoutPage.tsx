import React, { useState, useMemo, useCallback } from "react";
import { product } from "../data/product";

interface CheckoutPageProps {
  cartItems: CartItem[];
  onPlaceOrder: (customerInfo: { name: string; email: string; address: string; city: string; postcode: string }) => void;
  onBackToProduct: () => void;
  onOpenCart: () => void;
}

export default function CheckoutPage({
  cartItems,
  onPlaceOrder,
  onBackToProduct,
  onOpenCart,
}: CheckoutPageProps) {
  // Form State
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("");
  const [postcode, setPostcode] = useState("");
  const [country, setCountry] = useState("United Kingdom");
  const [cardNumber, setCardNumber] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCvv, setCardCvv] = useState("");

  // Validation State
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  // Subtotal Calculation
  const subtotal = useMemo(() => {
    return cartItems.reduce((acc, item) => {
      const variant = product.variants[item.variantIndex];
      return acc + variant.price * item.quantity;
    }, 0);
  }, [cartItems]);

  // Shipping Calculation (Free over £150, else £5.00)
  const shipping = useMemo(() => {
    if (subtotal === 0) return 0;
    return subtotal >= 150 ? 0 : 5.0;
  }, [subtotal]);

  // Total Calculation
  const total = useMemo(() => {
    return subtotal + shipping;
  }, [subtotal, shipping]);

  // Format Card Number (XXXX XXXX XXXX XXXX)
  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawVal = e.target.value.replace(/\D/g, "");
    const truncated = rawVal.slice(0, 16);
    const matches = truncated.match(/\d{1,4}/g);
    setCardNumber(matches ? matches.join(" ") : truncated);
  };

  // Format Card Expiry (MM/YY)
  const handleCardExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawVal = e.target.value.replace(/\D/g, "");
    const truncated = rawVal.slice(0, 4);
    if (truncated.length > 2) {
      setCardExpiry(`${truncated.slice(0, 2)}/${truncated.slice(2)}`);
    } else {
      setCardExpiry(truncated);
    }
  };

  // Format Card CVV (XXX)
  const handleCardCvvChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawVal = e.target.value.replace(/\D/g, "");
    setCardCvv(rawVal.slice(0, 3));
  };

  // Validate fields
  const validateForm = (): boolean => {
    const newErrors: { [key: string]: string } = {};

    if (!email) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = "Email address is invalid";
    }

    if (!phone) newErrors.phone = "Phone number is required";
    if (!firstName) newErrors.firstName = "First name is required";
    if (!lastName) newErrors.lastName = "Last name is required";
    if (!address) newErrors.address = "Address is required";
    if (!city) newErrors.city = "City is required";
    if (!postcode) newErrors.postcode = "Postcode is required";

    const cleanedCard = cardNumber.replace(/\s/g, "");
    if (!cardNumber) {
      newErrors.cardNumber = "Card number is required";
    } else if (cleanedCard.length !== 16) {
      newErrors.cardNumber = "Card number must be 16 digits";
    }

    if (!cardExpiry) {
      newErrors.cardExpiry = "Expiry date is required";
    } else if (!/^(0[1-9]|1[0-2])\/?([0-9]{2})$/.test(cardExpiry)) {
      newErrors.cardExpiry = "Expiry format must be MM/YY";
    }

    if (!cardCvv) {
      newErrors.cardCvv = "CVV is required";
    } else if (cardCvv.length !== 3) {
      newErrors.cardCvv = "CVV must be 3 digits";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onPlaceOrder({
        name: `${firstName} ${lastName}`,
        email,
        address,
        city,
        postcode,
      });
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-[var(--sp-md)] sm:px-[var(--sp-lg)] py-[var(--sp-md)] sm:py-[var(--sp-lg)] fade-in">
      {/* Navigation & Title */}
      <div className="mb-8">
        <button
          onClick={onBackToProduct}
          className="inline-flex items-center gap-1.5 text-sm font-medium text-secondary hover:text-primary transition-colors cursor-pointer focus-visible:outline-accent mb-4"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
          Back to Aurora Kettle Page
        </button>
        <h1 className="text-3xl font-extrabold text-primary tracking-tight">Secure Checkout</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:items-start">
        {/* Left Side: Checkout Form */}
        <form onSubmit={handleSubmit} className="lg:col-span-7 flex flex-col gap-6">
          {/* Contact Information */}
          <div className="bg-white p-6 rounded-[var(--radius-card)] border border-gray-100 shadow-sm flex flex-col gap-4">
            <h2 className="text-lg font-bold text-primary flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-primary text-white flex items-center justify-center text-xs">1</span>
              Contact Information
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex flex-col gap-1">
                <label htmlFor="email" className="text-xs font-semibold text-secondary">
                  Email Address
                </label>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={`px-4 py-2.5 bg-gray-50 border rounded-[var(--radius-button)] text-sm transition-all focus-visible:outline-accent ${errors.email ? "border-red-400 focus:border-red-400" : "border-gray-200 focus:bg-white"
                    }`}
                  placeholder="name@example.com"
                />
                {errors.email && <span className="text-xs font-medium text-red-500">{errors.email}</span>}
              </div>
              <div className="flex flex-col gap-1">
                <label htmlFor="phone" className="text-xs font-semibold text-secondary">
                  Phone Number
                </label>
                <input
                  id="phone"
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className={`px-4 py-2.5 bg-gray-50 border rounded-[var(--radius-button)] text-sm transition-all focus-visible:outline-accent ${errors.phone ? "border-red-400 focus:border-red-400" : "border-gray-200 focus:bg-white"
                    }`}
                  placeholder="+44 7123 456789"
                />
                {errors.phone && <span className="text-xs font-medium text-red-500">{errors.phone}</span>}
              </div>
            </div>
          </div>

          {/* Shipping Address */}
          <div className="bg-white p-6 rounded-[var(--radius-card)] border border-gray-100 shadow-sm flex flex-col gap-4">
            <h2 className="text-lg font-bold text-primary flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-primary text-white flex items-center justify-center text-xs">2</span>
              Shipping Address
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex flex-col gap-1">
                <label htmlFor="firstName" className="text-xs font-semibold text-secondary">
                  First Name
                </label>
                <input
                  id="firstName"
                  type="text"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  className={`px-4 py-2.5 bg-gray-50 border rounded-[var(--radius-button)] text-sm transition-all focus-visible:outline-accent ${errors.firstName ? "border-red-400 focus:border-red-400" : "border-gray-200 focus:bg-white"
                    }`}
                  placeholder="John"
                />
                {errors.firstName && <span className="text-xs font-medium text-red-500">{errors.firstName}</span>}
              </div>
              <div className="flex flex-col gap-1">
                <label htmlFor="lastName" className="text-xs font-semibold text-secondary">
                  Last Name
                </label>
                <input
                  id="lastName"
                  type="text"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  className={`px-4 py-2.5 bg-gray-50 border rounded-[var(--radius-button)] text-sm transition-all focus-visible:outline-accent ${errors.lastName ? "border-red-400 focus:border-red-400" : "border-gray-200 focus:bg-white"
                    }`}
                  placeholder="Doe"
                />
                {errors.lastName && <span className="text-xs font-medium text-red-500">{errors.lastName}</span>}
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <label htmlFor="address" className="text-xs font-semibold text-secondary">
                Street Address
              </label>
              <input
                id="address"
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className={`px-4 py-2.5 bg-gray-50 border rounded-[var(--radius-button)] text-sm transition-all focus-visible:outline-accent ${errors.address ? "border-red-400 focus:border-red-400" : "border-gray-200 focus:bg-white"
                  }`}
                placeholder="123 Ceramic Lane"
              />
              {errors.address && <span className="text-xs font-medium text-red-500">{errors.address}</span>}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="flex flex-col gap-1">
                <label htmlFor="city" className="text-xs font-semibold text-secondary">
                  City
                </label>
                <input
                  id="city"
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className={`px-4 py-2.5 bg-gray-50 border rounded-[var(--radius-button)] text-sm transition-all focus-visible:outline-accent ${errors.city ? "border-red-400 focus:border-red-400" : "border-gray-200 focus:bg-white"
                    }`}
                  placeholder="London"
                />
                {errors.city && <span className="text-xs font-medium text-red-500">{errors.city}</span>}
              </div>
              <div className="flex flex-col gap-1">
                <label htmlFor="postcode" className="text-xs font-semibold text-secondary">
                  Postcode
                </label>
                <input
                  id="postcode"
                  type="text"
                  value={postcode}
                  onChange={(e) => setPostcode(e.target.value)}
                  className={`px-4 py-2.5 bg-gray-50 border rounded-[var(--radius-button)] text-sm transition-all focus-visible:outline-accent ${errors.postcode ? "border-red-400 focus:border-red-400" : "border-gray-200 focus:bg-white"
                    }`}
                  placeholder="EC1A 1BB"
                />
                {errors.postcode && <span className="text-xs font-medium text-red-500">{errors.postcode}</span>}
              </div>
              <div className="flex flex-col gap-1">
                <label htmlFor="country" className="text-xs font-semibold text-secondary">
                  Country
                </label>
                <select
                  id="country"
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  className="px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-[var(--radius-button)] text-sm focus-visible:outline-accent focus:bg-white"
                >
                  <option value="United Kingdom">United Kingdom</option>
                  <option value="United States">United States</option>
                  <option value="Germany">Germany</option>
                  <option value="France">France</option>
                  <option value="Canada">Canada</option>
                </select>
              </div>
            </div>
          </div>

          {/* Payment Information */}
          <div className="bg-white p-6 rounded-[var(--radius-card)] border border-gray-100 shadow-sm flex flex-col gap-4">
            <h2 className="text-lg font-bold text-primary flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-primary text-white flex items-center justify-center text-xs">3</span>
              Payment Details
            </h2>
            <div className="flex flex-col gap-1">
              <label htmlFor="cardNumber" className="text-xs font-semibold text-secondary">
                Card Number
              </label>
              <div className="relative">
                <input
                  id="cardNumber"
                  type="text"
                  value={cardNumber}
                  onChange={handleCardNumberChange}
                  className={`w-full px-4 py-2.5 pl-11 bg-gray-50 border rounded-[var(--radius-button)] text-sm transition-all focus-visible:outline-accent ${errors.cardNumber ? "border-red-400 focus:border-red-400" : "border-gray-200 focus:bg-white"
                    }`}
                  placeholder="0000 0000 0000 0000"
                />
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                  </svg>
                </div>
              </div>
              {errors.cardNumber && <span className="text-xs font-medium text-red-500">{errors.cardNumber}</span>}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-1">
                <label htmlFor="cardExpiry" className="text-xs font-semibold text-secondary">
                  Expiry Date
                </label>
                <input
                  id="cardExpiry"
                  type="text"
                  value={cardExpiry}
                  onChange={handleCardExpiryChange}
                  className={`px-4 py-2.5 bg-gray-50 border rounded-[var(--radius-button)] text-sm transition-all focus-visible:outline-accent ${errors.cardExpiry ? "border-red-400 focus:border-red-400" : "border-gray-200 focus:bg-white"
                    }`}
                  placeholder="MM/YY"
                />
                {errors.cardExpiry && <span className="text-xs font-medium text-red-500">{errors.cardExpiry}</span>}
              </div>
              <div className="flex flex-col gap-1">
                <label htmlFor="cardCvv" className="text-xs font-semibold text-secondary">
                  CVV / CVC
                </label>
                <input
                  id="cardCvv"
                  type="password"
                  value={cardCvv}
                  onChange={handleCardCvvChange}
                  className={`px-4 py-2.5 bg-gray-50 border rounded-[var(--radius-button)] text-sm transition-all focus-visible:outline-accent ${errors.cardCvv ? "border-red-400 focus:border-red-400" : "border-gray-200 focus:bg-white"
                    }`}
                  placeholder="123"
                />
                {errors.cardCvv && <span className="text-xs font-medium text-red-500">{errors.cardCvv}</span>}
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-4 bg-accent hover:bg-[#e85555] text-white font-bold text-base rounded-[var(--radius-button)] shadow-lg shadow-accent/25 hover:shadow-xl hover:scale-[1.01] transition-all cursor-pointer focus-visible:outline-accent active:scale-[0.99] flex items-center justify-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
            </svg>
            Pay and Place Order (£{total.toFixed(2)})
          </button>
        </form>

        {/* Right Side: Order Summary */}
        <div className="lg:col-span-5 lg:sticky lg:top-24">
          <div className="bg-white rounded-[var(--radius-card)] border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-6 py-5 bg-gray-50/50 border-b border-gray-100 flex items-center justify-between">
              <h2 className="text-base font-bold text-primary">Order Summary</h2>
              <button
                type="button"
                onClick={onOpenCart}
                className="text-xs font-bold text-accent hover:text-[#e85555] transition-colors cursor-pointer focus-visible:outline-accent"
              >
                Modify Cart
              </button>
            </div>

            {/* Item List */}
            <div className="p-6 divide-y divide-gray-100 flex flex-col gap-4">
              {cartItems.map((item) => {
                const variant = product.variants[item.variantIndex];
                return (
                  <div key={item.variantIndex} className="flex gap-4 pt-4 first:pt-0">
                    <div className="w-12 h-12 bg-neutral-bg rounded-lg flex items-center justify-center border border-gray-100 shadow-sm shrink-0">
                      <span className="w-5 h-5 rounded-full border border-gray-300" style={{ backgroundColor: variant.color }} />
                    </div>
                    <div className="flex-1 flex flex-col justify-center">
                      <div className="flex justify-between items-start text-sm">
                        <h3 className="font-bold text-primary leading-tight">{product.name}</h3>
                        <span className="font-bold text-primary">£{(variant.price * item.quantity).toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-xs text-secondary mt-1">
                        <span>Color: {variant.name}</span>
                        <span>Qty: {item.quantity}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Calculations */}
            <div className="p-6 bg-gray-50/30 border-t border-gray-100 flex flex-col gap-3 text-sm">
              <div className="flex justify-between">
                <span className="text-secondary">Subtotal</span>
                <span className="font-bold text-primary">£{subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-secondary">Shipping</span>
                <span className="font-bold text-primary">
                  {shipping === 0 ? <span className="text-success uppercase tracking-wider font-extrabold text-xs">Free</span> : `£${shipping.toFixed(2)}`}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-secondary">VAT (20% included)</span>
                <span className="font-bold text-primary">£{(total * 0.2).toFixed(2)}</span>
              </div>
              <div className="border-t border-gray-200 my-1" />
              <div className="flex justify-between text-base">
                <span className="font-bold text-primary">Total to Pay</span>
                <span className="font-extrabold text-primary text-lg">£{total.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
