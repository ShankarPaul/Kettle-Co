/**
 * Quantity stepper component.
 * Features [−] [input] [+] controls with min/max bounds.
 * Supports keyboard: Arrow keys to change quantity, direct input editing.
 */

interface QuantityStepperProps {
  quantity: number;
  onQuantityChange: (qty: number) => void;
  min?: number;
  max?: number;
  disabled?: boolean;
}

export default function QuantityStepper({
  quantity,
  onQuantityChange,
  min = 1,
  max = 10,
  disabled = false,
}: QuantityStepperProps) {
  /** Clamp value between min and max */
  const clamp = (val: number) => Math.min(Math.max(val, min), max);

  const handleDecrement = () => {
    if (!disabled && quantity > min) {
      onQuantityChange(quantity - 1);
    }
  };

  const handleIncrement = () => {
    if (!disabled && quantity < max) {
      onQuantityChange(quantity + 1);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    // Allow empty string while typing
    if (raw === "") return;
    const parsed = parseInt(raw, 10);
    if (!isNaN(parsed)) {
      onQuantityChange(clamp(parsed));
    }
  };

  /** On blur, ensure we have a valid quantity */
  const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    const parsed = parseInt(e.target.value, 10);
    if (isNaN(parsed) || parsed < min) {
      onQuantityChange(min);
    } else if (parsed > max) {
      onQuantityChange(max);
    }
  };

  /** Arrow keys to change quantity */
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "ArrowUp") {
      e.preventDefault();
      handleIncrement();
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      handleDecrement();
    }
  };

  return (
    <div className="flex flex-col gap-[var(--sp-xs)]">
      <label className="text-sm font-semibold text-secondary">
        Quantity
      </label>
      <div className="flex items-center gap-0 border border-gray-300 rounded-[var(--radius-button)]
        overflow-hidden w-fit bg-white shadow-sm">
        {/* Minus button */}
        <button
          type="button"
          aria-label="Decrease quantity"
          onClick={handleDecrement}
          disabled={disabled || quantity <= min}
          className={`w-[44px] h-[44px] flex items-center justify-center
            text-lg font-bold transition-all duration-200 cursor-pointer
            border-r border-gray-300 select-none
            ${disabled || quantity <= min
              ? "text-gray-300 cursor-not-allowed bg-gray-50"
              : "text-primary hover:bg-gray-100 active:bg-gray-200"
            }`}
        >
          −
        </button>

        {/* Quantity input */}
        <input
          type="text"
          inputMode="numeric"
          pattern="[0-9]*"
          aria-label="Quantity"
          value={quantity}
          onChange={handleInputChange}
          onBlur={handleBlur}
          onKeyDown={handleKeyDown}
          disabled={disabled}
          className={`w-16 h-[44px] text-center text-base font-semibold
            border-none outline-none bg-transparent text-primary
            ${disabled ? "text-gray-400 cursor-not-allowed" : ""}`}
        />

        {/* Plus button */}
        <button
          type="button"
          aria-label="Increase quantity"
          onClick={handleIncrement}
          disabled={disabled || quantity >= max}
          className={`w-[44px] h-[44px] flex items-center justify-center
            text-lg font-bold transition-all duration-200 cursor-pointer
            border-l border-gray-300 select-none
            ${disabled || quantity >= max
              ? "text-gray-300 cursor-not-allowed bg-gray-50"
              : "text-primary hover:bg-gray-100 active:bg-gray-200"
            }`}
        >
          +
        </button>
      </div>
    </div>
  );
}
