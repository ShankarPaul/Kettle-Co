/**
 * Color variant selector component.
 * Renders square swatches for each product variant.
 * Handles out-of-stock states with visual feedback.
 * Fully keyboard accessible with Tab + Enter/Space.
 */

import type { ProductVariant } from "../data/product";

interface VariantSelectorProps {
  variants: ProductVariant[];
  selectedIndex: number;
  onSelectVariant: (index: number) => void;
  isLoading?: boolean;
}

export default function VariantSelector({
  variants,
  selectedIndex,
  onSelectVariant,
  isLoading = false,
}: VariantSelectorProps) {
  if (isLoading) {
    return (
      <div className="flex flex-col gap-[var(--sp-sm)]">
        <div className="skeleton h-5 w-20" />
        <div className="flex gap-[var(--sp-sm)]">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="skeleton w-[44px] h-[44px]" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <fieldset className="flex flex-col gap-[var(--sp-sm)]">
      <legend className="text-sm font-semibold text-secondary mb-1">
        Color:{" "}
        <span className="text-primary font-bold">
          {variants[selectedIndex].name}
        </span>
      </legend>

      <div className="flex flex-wrap gap-[var(--sp-sm)]" role="radiogroup">
        {variants.map((variant, index) => {
          const isSelected = selectedIndex === index;
          const isOutOfStock = !variant.inStock;

          return (
            <button
              key={variant.name}
              type="button"
              role="radio"
              aria-checked={isSelected}
              aria-label={`Select ${variant.name} color${isOutOfStock ? " - Sold Out" : ""}`}
              disabled={false} // Allow selection to show out-of-stock state
              onClick={() => onSelectVariant(index)}
              className={`group relative flex flex-col items-center gap-1 cursor-pointer
                transition-all duration-300 ease-in-out`}
            >
              {/* Swatch */}
              <div
                className={`w-[44px] h-[44px] rounded-[var(--radius-button)] border-2
                  transition-all duration-300 ease-in-out
                  ${isSelected
                    ? "border-accent ring-2 ring-accent/30 scale-110 shadow-md"
                    : "border-gray-300 hover:border-gray-400 hover:scale-105"
                  }
                  ${isOutOfStock ? "opacity-50" : ""}`}
                style={{ backgroundColor: variant.color }}
              >
                {/* Inner border for light colors (Cream) */}
                {variant.color === "#F5F5F5" && (
                  <div className="absolute inset-[3px] rounded-[5px] border border-gray-200" />
                )}

                {/* Diagonal line for out-of-stock */}
                {isOutOfStock && (
                  <svg
                    className="absolute inset-0 w-full h-full"
                    viewBox="0 0 44 44"
                    aria-hidden="true"
                  >
                    <line
                      x1="4"
                      y1="4"
                      x2="40"
                      y2="40"
                      stroke="currentColor"
                      strokeWidth="2"
                      className="text-gray-400"
                    />
                  </svg>
                )}
              </div>

              {/* Label */}
              <span
                className={`text-xs font-medium transition-colors duration-200
                  ${isSelected ? "text-primary" : "text-secondary"}
                  ${isOutOfStock ? "text-gray-400" : ""}`}
              >
                {isOutOfStock ? "Sold Out" : variant.name}
              </span>
            </button>
          );
        })}
      </div>
    </fieldset>
  );
}
