/**
 * Trust badges component.
 * Displays 3 trust indicators: Free Shipping, 30-Day Returns, 2-Year Warranty.
 * Uses inline SVG icons for crisp rendering at all sizes.
 */

interface Badge {
  icon: React.ReactNode;
  title: string;
  subtitle: string;
}

/** Truck icon for Free Shipping */
const TruckIcon = () => (
  <svg
    width="28"
    height="28"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.5"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
  >
    <path d="M1 3h15v13H1z" />
    <path d="M16 8h4l3 3v5h-7V8z" />
    <circle cx="5.5" cy="18.5" r="2.5" />
    <circle cx="18.5" cy="18.5" r="2.5" />
  </svg>
);

/** Refresh/return icon for 30-Day Returns */
const RefreshIcon = () => (
  <svg
    width="28"
    height="28"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.5"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
  >
    <polyline points="23 4 23 10 17 10" />
    <polyline points="1 20 1 14 7 14" />
    <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
  </svg>
);

/** Shield icon for 2-Year Warranty */
const ShieldIcon = () => (
  <svg
    width="28"
    height="28"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.5"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
  >
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
    <polyline points="9 12 11 14 15 10" />
  </svg>
);

const badges: Badge[] = [
  {
    icon: <TruckIcon />,
    title: "Free Shipping",
    subtitle: "On all orders",
  },
  {
    icon: <RefreshIcon />,
    title: "30-Day Returns",
    subtitle: "Hassle-free",
  },
  {
    icon: <ShieldIcon />,
    title: "2-Year Warranty",
    subtitle: "Full coverage",
  },
];

export default function TrustBadges() {
  return (
    <section aria-label="Trust and guarantee badges" className="mt-[var(--sp-lg)]">
      <div className="grid grid-cols-3 gap-[var(--sp-sm)] sm:gap-[var(--sp-md)]">
        {badges.map((badge) => (
          <div
            key={badge.title}
            className="flex flex-col items-center text-center gap-2 p-3 sm:p-4
              rounded-[var(--radius-card)] bg-white border border-gray-100
              shadow-sm hover:shadow-md transition-shadow duration-300"
          >
            <div className="text-accent">{badge.icon}</div>
            <div>
              <p className="text-xs sm:text-sm font-bold text-primary leading-tight">
                {badge.title}
              </p>
              <p className="text-[10px] sm:text-xs text-secondary mt-0.5">
                {badge.subtitle}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
