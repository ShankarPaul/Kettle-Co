/**
 * Product specifications table component.
 * Renders specs as a semantic HTML <table> with alternating row styles.
 */

import type { ProductSpec } from "../data/product";

interface ProductSpecsProps {
  specs: ProductSpec[];
  isLoading?: boolean;
}

export default function ProductSpecs({
  specs,
  isLoading = false,
}: ProductSpecsProps) {
  if (isLoading) {
    return (
      <div className="flex flex-col gap-[var(--sp-sm)]">
        <div className="skeleton h-6 w-40" />
        {[0, 1, 2, 3, 4].map((i) => (
          <div key={i} className="skeleton h-10 w-full" />
        ))}
      </div>
    );
  }

  return (
    <section aria-labelledby="specs-heading">
      <h2
        id="specs-heading"
        className="text-xl font-bold text-primary mb-[var(--sp-md)]"
      >
        Specifications
      </h2>

      <div className="overflow-hidden rounded-[var(--radius-card)] border border-gray-200 shadow-sm">
        <table className="w-full text-sm">
          <caption className="sr-only">Product specifications</caption>
          <thead className="sr-only">
            <tr>
              <th scope="col">Specification</th>
              <th scope="col">Value</th>
            </tr>
          </thead>
          <tbody>
            {specs.map((spec, index) => (
              <tr
                key={spec.label}
                className={`${index % 2 === 0 ? "bg-white" : "bg-gray-50"}
                  transition-colors duration-200 hover:bg-gray-100`}
              >
                <td className="px-4 py-3 font-semibold text-primary whitespace-nowrap">
                  {spec.label}
                </td>
                <td className="px-4 py-3 text-secondary text-right">
                  {spec.value}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
