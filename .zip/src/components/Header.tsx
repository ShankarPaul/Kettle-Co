import { useCallback } from "react";

interface HeaderProps {
  /** The total number of items in the cart */
  cartItemCount: number;
  /** Callback to toggle the cart drawer open/closed */
  onCartToggle: () => void;
  /** Current page view */
  currentView: "product" | "checkout" | "success";
  /** Callback to change the active page view */
  onNavigate: (view: "product" | "checkout" | "success") => void;
}

export default function Header({
  cartItemCount,
  onCartToggle,
  currentView,
  onNavigate,
}: HeaderProps) {
  const handleLogoClick = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    onNavigate("product");
  }, [onNavigate]);

  return (
    <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-gray-100 shadow-sm transition-all duration-200">
      <div className="max-w-7xl mx-auto px-[var(--sp-md)] sm:px-[var(--sp-lg)] h-16 sm:h-20 flex items-center justify-between">
        {/* Brand Logo */}
        <a
          href="#"
          onClick={handleLogoClick}
          aria-label="Kettle and Co. Home"
          className="flex items-center gap-2 group focus-visible:outline-accent"
        >
          <span className="text-xl sm:text-2xl font-extrabold tracking-tight text-primary font-heading relative">
            KETTLE <span className="text-accent">&</span> CO.
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-accent transition-all duration-300 group-hover:w-full" />
          </span>
        </a>

        {/* Action Elements */}
        <div className="flex items-center gap-4">
          {currentView !== "product" && (
            <button
              onClick={() => onNavigate("product")}
              className="text-sm font-medium text-secondary hover:text-primary transition-colors cursor-pointer hidden sm:block focus-visible:outline-accent"
            >
              Continue Shopping
            </button>
          )}

          {/* Cart Icon Toggle Button */}
          <button
            type="button"
            onClick={onCartToggle}
            aria-label={`Open shopping cart, ${cartItemCount} items`}
            className="relative p-2 rounded-full text-primary hover:bg-gray-50 active:scale-95 transition-all cursor-pointer focus-visible:outline-accent"
          >
            <svg
              className="w-6 h-6 transition-transform duration-300 group-hover:scale-110"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"
              />
            </svg>

            {/* Item Count Badge */}
            {cartItemCount > 0 && (
              <span
                className="absolute -top-1 -right-1 bg-accent text-white text-[10px] sm:text-xs font-bold
                  min-w-[18px] sm:min-w-[20px] h-[18px] sm:h-[20px] px-1 rounded-full flex items-center justify-center
                  border-2 border-white shadow-sm scale-in animate-pulse"
                style={{
                  animationDuration: "2s",
                }}
              >
                {cartItemCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
