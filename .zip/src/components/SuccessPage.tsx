import { useMemo } from "react";
import { product } from "../data/product";
import type { CartItem } from "./CartDrawer";

interface SuccessPageProps {
  cartItems: CartItem[];
  customerInfo: {
    name: string;
    email: string;
    address: string;
    city: string;
    postcode: string;
  };
  onContinueShopping: () => void;
}

export default function SuccessPage({
  cartItems,
  customerInfo,
  onContinueShopping,
}: SuccessPageProps) {
  // Generate random order number
  const orderNumber = useMemo(() => {
    return `KC-2026-${Math.floor(10000 + Math.random() * 90000)}`;
  }, []);

  // Generate estimated delivery date (3 days from now)
  const deliveryDate = useMemo(() => {
    const date = new Date();
    date.setDate(date.getDate() + 3);
    return date.toLocaleDateString("en-GB", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  }, []);

  // Pricing math
  const subtotal = useMemo(() => {
    return cartItems.reduce((acc, item) => {
      const variant = product.variants[item.variantIndex];
      return acc + variant.price * item.quantity;
    }, 0);
  }, [cartItems]);

  const shipping = subtotal >= 150 ? 0 : 5.0;
  const total = subtotal + shipping;

  return (
    <div className="max-w-3xl mx-auto px-[var(--sp-md)] py-[var(--sp-xl)] sm:py-[var(--sp-xl)] text-center fade-in">
      {/* Animated Success Checkmark */}
      <div className="flex justify-center mb-6">
        <div className="relative flex items-center justify-center w-20 h-20 bg-success/10 rounded-full border border-success/30 shadow-lg shadow-success/15">
          {/* Animated Pulse Ring */}
          <div className="absolute inset-0 rounded-full bg-success/20 animate-ping opacity-75" style={{ animationDuration: "1.5s" }} />

          <svg className="w-10 h-10 text-success relative z-10" fill="none" stroke="currentColor" strokeWidth="3" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
          </svg>
        </div>
      </div>

      <h1 className="text-3xl font-extrabold text-primary tracking-tight mb-2">Order Confirmed!</h1>
      <p className="text-secondary text-sm sm:text-base mb-8 max-w-md mx-auto leading-relaxed">
        Thank you for your purchase, <span className="font-bold text-primary">{customerInfo.name}</span>.
        We've sent a confirmation email to <span className="font-bold text-primary">{customerInfo.email}</span>.
      </p>

      {/* Order Info Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-left mb-8">
        <div className="bg-white p-5 rounded-[var(--radius-card)] border border-gray-100 shadow-sm flex flex-col gap-2">
          <span className="text-xs font-semibold text-secondary uppercase tracking-wider">Order Summary</span>
          <div className="flex flex-col text-sm">
            <span className="font-bold text-primary">Number: {orderNumber}</span>
            <span className="text-secondary mt-1">Est. Delivery: {deliveryDate}</span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-[var(--radius-card)] border border-gray-100 shadow-sm flex flex-col gap-2">
          <span className="text-xs font-semibold text-secondary uppercase tracking-wider">Shipping To</span>
          <div className="flex flex-col text-sm text-primary leading-tight">
            <span className="font-bold">{customerInfo.name}</span>
            <span className="text-secondary mt-1">{customerInfo.address}</span>
            <span className="text-secondary">{customerInfo.city}, {customerInfo.postcode}</span>
          </div>
        </div>
      </div>

      {/* Ordered Items Accordion-like Display */}
      <div className="bg-white rounded-[var(--radius-card)] border border-gray-100 shadow-sm overflow-hidden text-left mb-8">
        <div className="px-6 py-4 bg-gray-50/50 border-b border-gray-100 font-bold text-sm text-primary">
          Items Ordered ({cartItems.reduce((acc, item) => acc + item.quantity, 0)})
        </div>
        <div className="p-6 divide-y divide-gray-100 flex flex-col gap-4">
          {cartItems.map((item) => {
            const variant = product.variants[item.variantIndex];
            return (
              <div key={item.variantIndex} className="flex gap-4 pt-4 first:pt-0">
                <div className="w-10 h-10 bg-neutral-bg rounded-lg flex items-center justify-center border border-gray-100 shrink-0">
                  <span className="w-4 h-4 rounded-full border border-gray-300" style={{ backgroundColor: variant.color }} />
                </div>
                <div className="flex-1 flex items-center justify-between text-sm">
                  <div>
                    <h3 className="font-bold text-primary leading-tight">{product.name}</h3>
                    <p className="text-xs text-secondary mt-0.5">Color: {variant.name} &bull; Qty: {item.quantity}</p>
                  </div>
                  <span className="font-bold text-primary">£{(variant.price * item.quantity).toFixed(2)}</span>
                </div>
              </div>
            );
          })}
        </div>
        <div className="px-6 py-4 border-t border-gray-100 bg-gray-50/30 flex justify-between items-center text-sm">
          <span className="text-secondary font-medium">Total Paid</span>
          <span className="font-extrabold text-primary text-base">£{total.toFixed(2)}</span>
        </div>
      </div>

      {/* Continue Shopping button */}
      <button
        onClick={onContinueShopping}
        className="px-8 py-3.5 bg-primary hover:bg-neutral-text text-white font-bold rounded-[var(--radius-button)] shadow-md hover:shadow-lg transition-all active:scale-[0.98] cursor-pointer inline-flex items-center gap-2 focus-visible:outline-accent"
      >
        <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
        </svg>
        Continue Shopping
      </button>
    </div>
  );
}
