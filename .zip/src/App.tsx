/**
 * App.tsx — Main entry point and page orchestrator for Kettle & Co.
 *
 * Handles routing state ('product' | 'checkout' | 'success') and cart state
 * (saving to and loading from localStorage, adding items, quantity updates).
 */

import { useState, useEffect, useCallback, useMemo } from "react";
import { product } from "./data/product";
import Header from "./components/Header";
import CartDrawer from "./components/CartDrawer";
import CheckoutPage from "./components/CheckoutPage";
import SuccessPage from "./components/SuccessPage";
import Gallery from "./components/Gallery";
import VariantSelector from "./components/VariantSelector";
import QuantityStepper from "./components/QuantityStepper";
import AddToCart from "./components/AddToCart";
import ProductSpecs from "./components/ProductSpecs";
import TrustBadges from "./components/TrustBadges";
import Toast from "./components/Toast";

/** Star rating display — renders filled, half, and empty stars */
function StarRating({ rating, reviews }: { rating: number; reviews: number }) {
  const fullStars = Math.floor(rating);
  const hasHalf = rating % 1 >= 0.3;
  const emptyStars = 5 - fullStars - (hasHalf ? 1 : 0);

  return (
    <div className="flex items-center gap-2" aria-label={`${rating} out of 5 stars, ${reviews} reviews`}>
      <div className="flex gap-0.5">
        {/* Full stars */}
        {Array.from({ length: fullStars }).map((_, i) => (
          <svg key={`full-${i}`} className="star-filled w-5 h-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
          </svg>
        ))}

        {/* Half star */}
        {hasHalf && (
          <svg className="w-5 h-5" viewBox="0 0 20 20" aria-hidden="true">
            <defs>
              <linearGradient id="halfGrad">
                <stop offset="50%" stopColor="#F59E0B" />
                <stop offset="50%" stopColor="#D1D5DB" />
              </linearGradient>
            </defs>
            <path
              fill="url(#halfGrad)"
              d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"
            />
          </svg>
        )}

        {/* Empty stars */}
        {Array.from({ length: emptyStars }).map((_, i) => (
          <svg key={`empty-${i}`} className="star-empty w-5 h-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
          </svg>
        ))}
      </div>

      <span className="text-sm text-secondary font-medium">
        {rating} ({reviews} reviews)
      </span>
    </div>
  );
}

export default function App() {
  // ===========================
  // STATE & ROUTING
  // ===========================
  const [currentView, setCurrentView] = useState<"product" | "checkout" | "success">("product");
  const [isLoading, setIsLoading] = useState(true);
  const [selectedVariant, setSelectedVariant] = useState(0); // Default: Cream
  const [selectedImage, setSelectedImage] = useState(0);     // Default: main image
  const [quantity, setQuantity] = useState(1);
  const [showToast, setShowToast] = useState(false);

  // Cart Drawer open state
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Persistent Cart Items
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const stored = localStorage.getItem("kettle_co_cart");
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // Keep track of final checkout customer details & ordered items for SuccessPage
  const [customerInfo, setCustomerInfo] = useState<{
    name: string;
    email: string;
    address: string;
    city: string;
    postcode: string;
  } | null>(null);

  const [lastOrderedItems, setLastOrderedItems] = useState<CartItem[]>([]);

  // Derived state
  const currentVariant = product.variants[selectedVariant];
  const isInStock = currentVariant.inStock;

  // Persist cart modifications
  useEffect(() => {
    try {
      localStorage.setItem("kettle_co_cart", JSON.stringify(cartItems));
    } catch (e) {
      console.error("Error writing to localStorage", e);
    }
  }, [cartItems]);

  // ===========================
  // LOADING SIMULATION (2 seconds)
  // ===========================
  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  // Compute total item count in cart
  const totalItemCount = useMemo(() => {
    return cartItems.reduce((acc, item) => acc + item.quantity, 0);
  }, [cartItems]);

  // ===========================
  // HANDLERS
  // ===========================
  const handleVariantChange = useCallback((index: number) => {
    setSelectedVariant(index);
    setSelectedImage(0);
  }, []);

  const handleAddToCart = useCallback(() => {
    if (!isInStock) return;

    setCartItems((prev) => {
      const idx = prev.findIndex((item) => item.variantIndex === selectedVariant);
      if (idx > -1) {
        const next = [...prev];
        const nextQty = Math.min(10, next[idx].quantity + quantity);
        next[idx] = { ...next[idx], quantity: nextQty };
        return next;
      }
      return [...prev, { variantIndex: selectedVariant, quantity }];
    });

    setShowToast(true);

    // Open Cart Drawer automatically after addition for top-tier visual flow
    setTimeout(() => {
      setIsCartOpen(true);
    }, 600);
  }, [selectedVariant, quantity, isInStock]);

  const handleToastClose = useCallback(() => {
    setShowToast(false);
  }, []);

  const handleUpdateCartQuantity = useCallback((variantIdx: number, newQty: number) => {
    if (newQty < 1 || newQty > 10) return;
    setCartItems((prev) =>
      prev.map((item) =>
        item.variantIndex === variantIdx ? { ...item, quantity: newQty } : item
      )
    );
  }, []);

  const handleRemoveCartItem = useCallback((variantIdx: number) => {
    setCartItems((prev) => prev.filter((item) => item.variantIndex !== variantIdx));
  }, []);

  const handleNavigate = useCallback((view: "product" | "checkout" | "success") => {
    setCurrentView(view);
  }, []);

  const handlePlaceOrder = useCallback((info: { name: string; email: string; address: string; city: string; postcode: string }) => {
    setCustomerInfo(info);
    setLastOrderedItems(cartItems);
    setCartItems([]); // Reset active cart
    setCurrentView("success");
  }, [cartItems]);

  const handleContinueShopping = useCallback(() => {
    setCustomerInfo(null);
    setLastOrderedItems([]);
    setCurrentView("product");
  }, []);

  // ===========================
  // RENDER VIEWS
  // ===========================
  return (
    <>
      {/* Premium Navigation Header */}
      <Header
        cartItemCount={totalItemCount}
        onCartToggle={() => setIsCartOpen((prev) => !prev)}
        currentView={currentView}
        onNavigate={handleNavigate}
      />

      {/* Main content body containing current view */}
      {currentView === "product" && (
        <>
          {/* Breadcrumb section */}
          <div className="bg-white border-b border-gray-100">
            <div className="max-w-7xl mx-auto px-[var(--sp-md)] sm:px-[var(--sp-lg)] py-3">
              <nav aria-label="Breadcrumb" className="text-sm text-secondary">
                <ol className="flex items-center gap-2">
                  <li>
                    <a href="#" onClick={(e) => { e.preventDefault(); handleNavigate("product"); }} className="hover:text-accent transition-colors duration-200">
                      Home
                    </a>
                  </li>
                  <li aria-hidden="true" className="text-gray-300">/</li>
                  <li>
                    <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-accent transition-colors duration-200">
                      Kettles
                    </a>
                  </li>
                  <li aria-hidden="true" className="text-gray-300">/</li>
                  <li>
                    <span className="text-primary font-medium">{product.name}</span>
                  </li>
                </ol>
              </nav>
            </div>
          </div>

          <main className="max-w-7xl mx-auto px-[var(--sp-sm)] sm:px-[var(--sp-md)] lg:px-[var(--sp-lg)] py-[var(--sp-md)] sm:py-[var(--sp-lg)]">
            <div className={`${!isLoading ? "fade-in" : ""}`}>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-[var(--sp-md)] sm:gap-[var(--sp-lg)]">
                {/* LEFT COLUMN: Image Gallery */}
                <div className="lg:sticky lg:top-24 lg:self-start">
                  <Gallery
                    images={product.images}
                    selectedImageIndex={selectedImage}
                    onSelectImage={setSelectedImage}
                    isLoading={isLoading}
                  />
                </div>

                {/* RIGHT COLUMN: Product Info */}
                <div className="flex flex-col gap-[var(--sp-md)] sm:gap-6">
                  {isLoading ? (
                    <div className="flex flex-col gap-[var(--sp-sm)]">
                      <div className="skeleton h-10 w-3/4" />
                      <div className="skeleton h-6 w-1/3" />
                      <div className="skeleton h-5 w-1/2" />
                      <div className="skeleton h-16 w-full" />
                    </div>
                  ) : (
                    <div>
                      <h1 className="text-2xl sm:text-[28px] lg:text-[32px] font-bold text-primary leading-tight tracking-tight">
                        {product.name}
                      </h1>
                      <p className="text-2xl sm:text-3xl font-bold text-accent mt-2 tracking-tight">
                        £{currentVariant.price.toFixed(2)}
                      </p>
                      <div className="mt-2">
                        <StarRating rating={product.rating} reviews={product.reviews} />
                      </div>
                      <p className="text-sm sm:text-base text-secondary mt-3 leading-relaxed max-w-lg">
                        {product.description}
                      </p>
                    </div>
                  )}

                  <hr className="border-gray-200" />

                  <VariantSelector
                    variants={product.variants}
                    selectedIndex={selectedVariant}
                    onSelectVariant={handleVariantChange}
                    isLoading={isLoading}
                  />

                  {!isLoading && !isInStock && (
                    <div
                      className="flex items-center gap-2 px-4 py-3 rounded-[var(--radius-button)] bg-red-50 border border-red-200 text-sm text-red-700 font-medium fade-in"
                      role="alert"
                    >
                      <svg className="w-5 h-5 text-red-400 shrink-0" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                      </svg>
                      This color is currently out of stock
                    </div>
                  )}

                  <div className="flex flex-col sm:flex-row items-stretch sm:items-end gap-[var(--sp-md)]">
                    <QuantityStepper
                      quantity={quantity}
                      onQuantityChange={setQuantity}
                      disabled={!isInStock}
                    />
                    <AddToCart
                      inStock={isInStock}
                      onAddToCart={handleAddToCart}
                      isLoading={isLoading}
                    />
                  </div>

                  {!isLoading && <TrustBadges />}
                  {!isLoading && <hr className="border-gray-200" />}
                  <ProductSpecs specs={product.specs} isLoading={isLoading} />
                </div>
              </div>
            </div>
          </main>
        </>
      )}

      {currentView === "checkout" && (
        <CheckoutPage
          cartItems={cartItems}
          onPlaceOrder={handlePlaceOrder}
          onBackToProduct={() => handleNavigate("product")}
          onOpenCart={() => setIsCartOpen(true)}
        />
      )}

      {currentView === "success" && customerInfo && (
        <SuccessPage
          cartItems={lastOrderedItems}
          customerInfo={customerInfo}
          onContinueShopping={handleContinueShopping}
        />
      )}

      {/* Footer */}
      <footer className="bg-white border-t border-gray-100 mt-[var(--sp-lg)]">
        <div className="max-w-7xl mx-auto px-[var(--sp-md)] sm:px-[var(--sp-lg)] py-6 text-center text-sm text-secondary">
          © 2026 Kettle & Co. All rights reserved.
        </div>
      </footer>

      {/* Slide-out Cart Drawer Overlay */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onCheckout={() => handleNavigate("checkout")}
      />

      {/* Success toast notification */}
      {showToast && (
        <Toast
          message={`Added ${quantity}x ${product.name} (${currentVariant.name}) to cart`}
          duration={3000}
          onClose={handleToastClose}
          type="success"
        />
      )}
    </>
  );
}

